import React from 'react';
import { Clock, Award, Users } from 'lucide-react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 relative">
            <div className="rounded-xl overflow-hidden shadow-xl z-10 relative">
              <img 
                src="https://images.pexels.com/photos/2253643/pexels-photo-2253643.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Our café interior" 
                className="w-full h-auto"
              />
            </div>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-amber-200 rounded-xl -z-10 transform -rotate-6"></div>
          </div>
          
          <div className="lg:w-1/2 space-y-6">
            <h2 className="text-3xl md:text-4xl font-bold text-amber-900">About DelíciaCafé</h2>
            <p className="text-gray-700">
              Since 2010, we've been serving up delicious, homemade food to our community. 
              What started as a small family business has grown into a beloved local favorite 
              where people come together to enjoy good food in a warm, welcoming atmosphere.
            </p>
            <p className="text-gray-700">
              We believe in using fresh, locally-sourced ingredients whenever possible and 
              preparing everything with care and attention to detail.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              <div className="flex flex-col items-center text-center p-4 rounded-lg bg-amber-50">
                <Clock className="w-8 h-8 text-amber-500 mb-2" />
                <h3 className="font-bold text-amber-800">Opening Hours</h3>
                <p className="text-sm text-gray-600">Mon-Fri: 7am - 8pm</p>
                <p className="text-sm text-gray-600">Sat-Sun: 8am - 9pm</p>
              </div>
              
              <div className="flex flex-col items-center text-center p-4 rounded-lg bg-amber-50">
                <Award className="w-8 h-8 text-amber-500 mb-2" />
                <h3 className="font-bold text-amber-800">Quality Food</h3>
                <p className="text-sm text-gray-600">Fresh ingredients with authentic recipes</p>
              </div>
              
              <div className="flex flex-col items-center text-center p-4 rounded-lg bg-amber-50">
                <Users className="w-8 h-8 text-amber-500 mb-2" />
                <h3 className="font-bold text-amber-800">Family Owned</h3>
                <p className="text-sm text-gray-600">Serving the community with love since 2010</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;