import { MenuItemType } from '../types';

export const menuData: MenuItemType[] = [
  {
    id: 1,
    name: "Classic Cheeseburger",
    description: "Juicy beef patty, cheddar cheese, lettuce, tomato, and our special sauce on a brioche bun",
    price: 9.99,
    category: "Burgers",
    image: "https://images.pexels.com/photos/1639557/pexels-photo-1639557.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: true
  },
  {
    id: 2,
    name: "Chicken Club Sandwich",
    description: "Grilled chicken breast with bacon, avocado, lettuce, tomato, and mayo on toasted sourdough",
    price: 8.99,
    category: "Sandwiches",
    image: "https://images.pexels.com/photos/1647163/pexels-photo-1647163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: false
  },
  {
    id: 3,
    name: "Veggie Wrap",
    description: "Hummus, roasted vegetables, mixed greens, and feta cheese in a whole wheat wrap",
    price: 7.99,
    category: "Sandwiches",
    image: "https://images.pexels.com/photos/2347311/pexels-photo-2347311.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: false
  },
  {
    id: 4,
    name: "Caesar Salad",
    description: "Crisp romaine, parmesan cheese, croutons, and our homemade Caesar dressing",
    price: 8.49,
    category: "Salads",
    image: "https://images.pexels.com/photos/1211887/pexels-photo-1211887.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: false
  },
  {
    id: 5,
    name: "French Fries",
    description: "Crispy golden fries seasoned with our special herb blend",
    price: 3.99,
    category: "Sides",
    image: "https://images.pexels.com/photos/1583884/pexels-photo-1583884.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: true
  },
  {
    id: 6,
    name: "Cappuccino",
    description: "Espresso with steamed milk and a light layer of foam",
    price: 4.49,
    category: "Beverages",
    image: "https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: true
  },
  {
    id: 7,
    name: "Chocolate Brownie",
    description: "Rich, fudgy brownie served warm with vanilla ice cream",
    price: 5.99,
    category: "Desserts",
    image: "https://images.pexels.com/photos/45202/brownie-dessert-cake-sweet-45202.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: false
  },
  {
    id: 8,
    name: "BBQ Bacon Burger",
    description: "Beef patty, crispy bacon, cheddar cheese, and BBQ sauce on a pretzel bun",
    price: 11.99,
    category: "Burgers",
    image: "https://images.pexels.com/photos/2702674/pexels-photo-2702674.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: false
  },
  {
    id: 9,
    name: "Fresh Lemonade",
    description: "Freshly squeezed lemonade with a hint of mint",
    price: 3.49,
    category: "Beverages",
    image: "https://images.pexels.com/photos/2109099/pexels-photo-2109099.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    isPopular: false
  }
];